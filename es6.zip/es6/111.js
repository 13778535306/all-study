this.onmessage=function(res){
	var data=res.data;
	var arr=[];
	arr.push(data);
	this.postMessage(arr);


	// var lastData=data.charCodeAt(0).toUpperCase()+data.substring(1);
	// this.postMessage(lastData);

	// setInerval(()=>{
	// 	this.postMessage(Math.random())
	// },30); 
}