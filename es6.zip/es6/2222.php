<?php

echo "2222";
$user=$_['name'];
$pass=$_['pass']

if($user=='leo' && $pass='123456'){
	echo"{
		ok:1,
		data:'登录成功'
	}";
}
else{
	echo"{
		ok:2,
		data:"登录失败"
	}"
}

?>